from neo4j import GraphDatabase

class Neo4JDatabase:

    def __init__(self,connection_details):
        usermame = connection_details['username']
        password = connection_details['password']
        host = connection_details.get('host',"localhost")
        port = connection_details.get('port',"7474")
    
        # Écrire la ligne pour se connecter
        self.client = GraphDatabase()
    
    def is_data_in_database(self):
        pass
    
    def save_data(self):
        # Écrire la fonction. Assurez-vous que les relations sont faites avec les autres noeuds!
        pass
    