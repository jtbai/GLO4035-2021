import csv

class LocalCSV:
    
    def __init__(self, path):
        self.path = path
        
    def get_data(self):
        # Écrire la fonction pour extraire les données du CSV
        
        data = [] # Modifier cette ligne
        
        return data