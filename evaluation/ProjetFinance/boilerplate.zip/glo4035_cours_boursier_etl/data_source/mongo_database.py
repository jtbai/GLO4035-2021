from pymongo import MongoClient

class MongoDatabase:
    
    def __init__(self, connection_detail):
        if connection_detail is None:
            host = "localhost"
            port = 27017
            
        self.client = MongoClient(host, port)
    
    def create_collection(self, collection_name):
        # Valider que la collection n'existe pas déjà?
        pass # À écrire
    
    def save_document(self, collection_name, document):
        pass # A Écrire
    