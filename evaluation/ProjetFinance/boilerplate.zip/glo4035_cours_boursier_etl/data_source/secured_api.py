import requests

class SecuredApi:
    
    def __init__(self, url, auth):
        self.url = url
        self.auth = auth
        
    def get_data(self):
        # Modifier la fonction pour recevoir ce qu'on a besoin de yahoo !
        # response = requests.get(self.url, auth=self.auth)
        # converted_response = response.content.decode("UTF8")
        converted_response = [] # Modifier 
        return converted_response