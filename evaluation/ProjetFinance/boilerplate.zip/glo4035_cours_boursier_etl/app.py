from http import HTTPStatus
from flask import Flask
from flask import jsonify
from flask import Response


import json
from data_source import SecuredApi, LocalCSV
from data_source.neo4j_database import Neo4JDatabase

HOST = "0.0.0.0"
PORT = "8081"

YAHOO_CONNECTION_DETAIL_PATH = "connection_details/yahoo_connection_details.json"
NEO4J_CONNECTION_DETAIL_PATH = "connection_details/neo4j_connection_details.json"
INFORMATION_PATH = "hand_extracted_data/wikipedia.csv"

application = Flask("cours_boursier")

@application.route("/", methods = ["GET"])
def home():
    return "<a href=/extract_data>Extraires les données</a>"

@application.route("/extract_data", methods = ["GET"])
def extract_data():
    yahoo_connection_details = json.load(open(YAHOO_CONNECTION_DETAIL_PATH,'r'))
    yahoo_api = SecuredApi(yahoo_connection_details['url'], yahoo_connection_details['auth'])
    local_csv = LocalCSV(INFORMATION_PATH)
    
    neo4j_connection_details = json.load(open(NEO4J_CONNECTION_DETAIL_PATH,'r'))
    neo4j_database = Neo4JDatabase(neo4j_connection_details)
    
    for datasource in [yahoo_api, local_csv]:
        for datapoint in datasource.get_data():
            neo4j_database.save_data(datapoint)

    return Response(status = 201) # 201 == "j'ai créé les trucs!"

@application.route("/extracted_data", methods= ["GET"])
def show_extracted_data():
    # Mettre le retour de la vu simple
    return jsonify({})

@application.route("/transformed_data/<dataset>/<date>", methods= ["GET"])
def show_transformed_data(dataset, date):
    # Mettre le retour des vues transformées
    return jsonify({})


if __name__ == "__main__":
    application.run(host=HOST, port=PORT, debug=True)